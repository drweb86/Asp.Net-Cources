﻿namespace SiarheiKuchuk.Test8.BL.ViewModels
{
    public class UserViewModel
    {
        public int User_UID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
