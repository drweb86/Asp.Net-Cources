namespace SiarheiKuchuk.Test8.Web.Controllers
{
    class CookieHelper
    {
        public const string CookieName = "supersite";
    }
}