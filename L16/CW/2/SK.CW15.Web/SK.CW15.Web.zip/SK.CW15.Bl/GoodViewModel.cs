namespace SK.CW15.Bl
{
    public class GoodViewModel
    {
        public int Good_UID { get; set; }
        public string Title { get; set; }
        public int Price { get; set; }
    }
}